;
(function(d,w,n,c,$){
    //programacion que se actuva cuandl el documento HTML ha cargado el navegador
    $(d).ready(function(){
        //metodo que activa la barra de navegacion
        $(".button-collapse").sideNav()
    })
})(document, window, navigator, console.log, jQuery);//son los objetos principales de JS
